import gspread
from google.oauth2.service_account import Credentials
import csv
import os

SHEET_ID = "1aXBrirW5ktKaMtr5cPGS5oU23eOKhk_8OnZHah2__rc"
CREDENTIALS_FILE = "/opt/airflow/scripts/google_credentials.json"

GOLD_CSV = "/opt/airflow/data/delta/asteroid_gold/snapshot_1782859186/data.csv"
SILVER_CSV = "/opt/airflow/data/delta/asteroid_silver/snapshot_1782859186/data.csv"
BRONZE_CSV = "/opt/airflow/data/delta/asteroid_bronze/snapshot_1782859186/data.csv"

def read_csv(path):
    with open(path, "r") as f:
        reader = csv.reader(f)
        return list(reader)

def upload_sheet(client, sheet_id, tab_name, data):
    spreadsheet = client.open_by_key(sheet_id)
    
    try:
        worksheet = spreadsheet.worksheet(tab_name)
        worksheet.clear()
    except gspread.exceptions.WorksheetNotFound:
        worksheet = spreadsheet.add_worksheet(title=tab_name, rows=1000, cols=30)
    
    worksheet.update(data)
    print(f"✅ Uploaded {len(data)-1} rows to '{tab_name}' tab")

def upload_to_sheets():
    print("Connecting to Google Sheets...")
    
    scopes = [
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/drive"
    ]
    
    creds = Credentials.from_service_account_file(CREDENTIALS_FILE, scopes=scopes)
    client = gspread.authorize(creds)
    
    # Upload Bronze
    print("Reading Bronze data...")
    bronze_data = read_csv(BRONZE_CSV)
    upload_sheet(client, SHEET_ID, "Bronze", bronze_data)
    
    # Upload Silver
    print("Reading Silver data...")
    silver_data = read_csv(SILVER_CSV)
    upload_sheet(client, SHEET_ID, "Silver", silver_data)
    
    # Upload Gold
    print("Reading Gold data...")
    gold_data = read_csv(GOLD_CSV)
    upload_sheet(client, SHEET_ID, "Gold", gold_data)
    
    print("🎉 All 3 layers uploaded to Google Sheets successfully!")

if __name__ == "__main__":
    upload_to_sheets()